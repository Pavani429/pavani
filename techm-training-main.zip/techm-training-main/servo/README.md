# prime.servo

Spring Boot, Hibernate vehicle management assignment by liyakhath syed
